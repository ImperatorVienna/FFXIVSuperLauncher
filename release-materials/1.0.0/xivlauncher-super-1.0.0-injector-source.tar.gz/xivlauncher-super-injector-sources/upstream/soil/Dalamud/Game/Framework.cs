using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Dalamud.Configuration.Internal;
using Dalamud.Hooking;
using Dalamud.IoC;
using Dalamud.IoC.Internal;
using Dalamud.Logging.Internal;
using Dalamud.Plugin.Internal;
using Dalamud.Plugin.Internal.Types;
using Dalamud.Plugin.Services;
using Dalamud.Utility;

using CSFramework = FFXIVClientStructs.FFXIV.Client.System.Framework.Framework;

namespace Dalamud.Game;

/// <summary>
/// This class represents the Framework of the native game client and grants access to various subsystems.
/// </summary>
[ServiceManager.EarlyLoadedService]
internal sealed class Framework : IInternalDisposableService, IFramework
{
    private static readonly ModuleLog Log = ModuleLog.Create<Framework>();

    private static readonly Stopwatch StatsStopwatch = new();

    private readonly Stopwatch updateStopwatch = new();

    private readonly Hook<CSFramework.Delegates.Tick> updateHook;

    [ServiceManager.ServiceDependency]
    private readonly GameLifecycle lifecycle = Service<GameLifecycle>.Get();

    [ServiceManager.ServiceDependency]
    private readonly DalamudConfiguration configuration = Service<DalamudConfiguration>.Get();

    private readonly CancellationTokenSource frameworkDestroy;
    private readonly CancellationTokenSource frameworkDestroyed;
    private readonly ThreadBoundTaskScheduler frameworkThreadTaskScheduler;

    private readonly ConcurrentDictionary<TaskCompletionSource, (ulong Expire, CancellationToken CancellationToken)>
        tickDelayedTaskCompletionSources = new();

    private ulong tickCounter;

    [ServiceManager.ServiceConstructor]
    private unsafe Framework()
    {
        this.frameworkDestroy = new();
        this.frameworkDestroyed = new();
        this.frameworkThreadTaskScheduler = new();
        this.FrameworkThreadTaskFactory = new(
            this.frameworkDestroyed.Token,
            TaskCreationOptions.None,
            TaskContinuationOptions.None,
            this.frameworkThreadTaskScheduler);

        this.updateHook = Hook<CSFramework.Delegates.Tick>.FromAddress((nint)CSFramework.StaticVirtualTablePointer->Tick, this.HandleFrameworkUpdate);

        this.updateHook.Enable();
    }

    /// <inheritdoc/>
    public event IFramework.OnUpdateDelegate? Update;

    /// <summary>
    /// Executes during FrameworkUpdate before all <see cref="Update"/> delegates.
    /// </summary>
    internal event IFramework.OnUpdateDelegate? BeforeUpdate;

    /// <summary>
    /// Gets or sets a value indicating whether the collection of stats is enabled.
    /// </summary>
    public static bool StatsEnabled { get; set; }

    /// <summary>
    /// Gets the stats history mapping.
    /// </summary>
    public static Dictionary<string, List<double>> StatsHistory { get; } = [];

    /// <inheritdoc/>
    public DateTime LastUpdate { get; private set; } = DateTime.MinValue;

    /// <inheritdoc/>
    public DateTime LastUpdateUTC { get; private set; } = DateTime.MinValue;

    /// <inheritdoc/>
    public TimeSpan UpdateDelta { get; private set; } = TimeSpan.Zero;

    /// <inheritdoc/>
    public bool IsInFrameworkUpdateThread => this.frameworkThreadTaskScheduler.IsOnBoundThread;

    /// <inheritdoc/>
    public bool IsFrameworkUnloading => this.frameworkDestroy.IsCancellationRequested;

    /// <summary>
    /// Gets the list of update sub-delegates that didn't get updated this frame.
    /// </summary>
    internal List<string> NonUpdatedSubDelegates { get; private set; } = [];

    /// <summary>
    /// Gets the dictionary of delegates and hitch log time.
    /// </summary>
    internal Dictionary<string, DateTime> HitchLogHistory { get; private set; } = [];

    /// <summary>
    /// Gets or sets a value indicating whether to dispatch update events.
    /// </summary>
    internal bool DispatchUpdateEvents { get; set; } = true;

    private TaskFactory FrameworkThreadTaskFactory { get; }

    /// <inheritdoc/>
    public TaskFactory GetTaskFactory() => this.FrameworkThreadTaskFactory;

    /// <inheritdoc/>
    public Task DelayTicks(long numTicks, CancellationToken cancellationToken = default)
    {
        if (this.frameworkDestroyed.IsCancellationRequested) // Gone
            return Task.FromCanceled(this.frameworkDestroyed.Token);

        if (numTicks <= 0 || this.frameworkThreadTaskScheduler.BoundThread == null) // Nonsense or before first tick
            return Task.CompletedTask;

        var tcs = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        this.tickDelayedTaskCompletionSources[tcs] = (this.tickCounter + (ulong)numTicks, cancellationToken);
        return tcs.Task;
    }

    /// <inheritdoc/>
    public Task Run(Action action, CancellationToken cancellationToken = default)
    {
        if (cancellationToken == default)
            cancellationToken = this.FrameworkThreadTaskFactory.CancellationToken;
        return this.FrameworkThreadTaskFactory.StartNew(action, cancellationToken);
    }

    /// <inheritdoc/>
    public Task<T> Run<T>(Func<T> action, CancellationToken cancellationToken = default)
    {
        if (cancellationToken == default)
            cancellationToken = this.FrameworkThreadTaskFactory.CancellationToken;
        return this.FrameworkThreadTaskFactory.StartNew(action, cancellationToken);
    }

    /// <inheritdoc/>
    public Task Run(Func<Task> action, CancellationToken cancellationToken = default)
    {
        if (cancellationToken == default)
            cancellationToken = this.FrameworkThreadTaskFactory.CancellationToken;
        return this.FrameworkThreadTaskFactory.StartNew(action, cancellationToken).Unwrap();
    }

    /// <inheritdoc/>
    public Task<T> Run<T>(Func<Task<T>> action, CancellationToken cancellationToken = default)
    {
        if (cancellationToken == default)
            cancellationToken = this.FrameworkThreadTaskFactory.CancellationToken;
        return this.FrameworkThreadTaskFactory.StartNew(action, cancellationToken).Unwrap();
    }

    /// <inheritdoc/>
    public Task<T> RunOnFrameworkThread<T>(Func<T> func) =>
        this.IsInFrameworkUpdateThread || this.frameworkDestroyed.IsCancellationRequested ? Task.FromResult(func()) : this.RunOnTick(func);

    /// <inheritdoc/>
    public Task RunOnFrameworkThread(Action action)
    {
        if (this.IsInFrameworkUpdateThread || this.frameworkDestroyed.IsCancellationRequested)
        {
            try
            {
                action();
                return Task.CompletedTask;
            }
            catch (Exception ex)
            {
                return Task.FromException(ex);
            }
        }
        else
        {
            return this.RunOnTick(action);
        }
    }

    /// <inheritdoc/>
    public Task<T> RunOnFrameworkThread<T>(Func<Task<T>> func) =>
        this.IsInFrameworkUpdateThread || this.frameworkDestroyed.IsCancellationRequested ? func() : this.RunOnTick(func);

    /// <inheritdoc/>
    public Task RunOnFrameworkThread(Func<Task> func) =>
        this.IsInFrameworkUpdateThread || this.frameworkDestroyed.IsCancellationRequested ? func() : this.RunOnTick(func);

    /// <inheritdoc/>
    public Task<T> RunOnTick<T>(Func<T> func, TimeSpan delay = default, int delayTicks = default, CancellationToken cancellationToken = default)
    {
        if (this.frameworkDestroyed.IsCancellationRequested)
        {
            if (delay == default && delayTicks == default)
                return this.RunOnFrameworkThread(func);

            return Task.FromCanceled<T>(this.frameworkDestroyed.Token);
        }

        if (cancellationToken == default)
            cancellationToken = this.FrameworkThreadTaskFactory.CancellationToken;
        return this.FrameworkThreadTaskFactory.ContinueWhenAll(
            [
                Task.Delay(delay, cancellationToken),
                this.DelayTicks(delayTicks, cancellationToken),
            ],
            _ => func(),
            cancellationToken,
            TaskContinuationOptions.HideScheduler,
            this.frameworkThreadTaskScheduler);
    }

    /// <inheritdoc/>
    public Task RunOnTick(Action action, TimeSpan delay = default, int delayTicks = default, CancellationToken cancellationToken = default)
    {
        if (this.frameworkDestroyed.IsCancellationRequested)
        {
            if (delay == default && delayTicks == default)
                return this.RunOnFrameworkThread(action);

            return Task.FromCanceled(this.frameworkDestroyed.Token);
        }

        if (cancellationToken == default)
            cancellationToken = this.FrameworkThreadTaskFactory.CancellationToken;
        return this.FrameworkThreadTaskFactory.ContinueWhenAll(
            [
                Task.Delay(delay, cancellationToken),
                this.DelayTicks(delayTicks, cancellationToken),
            ],
            _ => action(),
            cancellationToken,
            TaskContinuationOptions.HideScheduler,
            this.frameworkThreadTaskScheduler);
    }

    /// <inheritdoc/>
    public Task<T> RunOnTick<T>(Func<Task<T>> func, TimeSpan delay = default, int delayTicks = default, CancellationToken cancellationToken = default)
    {
        if (this.frameworkDestroyed.IsCancellationRequested)
        {
            if (delay == default && delayTicks == default)
                return this.RunOnFrameworkThread(func);

            return Task.FromCanceled<T>(this.frameworkDestroyed.Token);
        }

        if (cancellationToken == default)
            cancellationToken = this.FrameworkThreadTaskFactory.CancellationToken;
        return this.FrameworkThreadTaskFactory.ContinueWhenAll(
            [
                Task.Delay(delay, cancellationToken),
                this.DelayTicks(delayTicks, cancellationToken),
            ],
            _ => func(),
            cancellationToken,
            TaskContinuationOptions.HideScheduler,
            this.frameworkThreadTaskScheduler).Unwrap();
    }

    /// <inheritdoc/>
    public Task RunOnTick(Func<Task> func, TimeSpan delay = default, int delayTicks = default, CancellationToken cancellationToken = default)
    {
        if (this.frameworkDestroyed.IsCancellationRequested)
        {
            if (delay == default && delayTicks == default)
                return this.RunOnFrameworkThread(func);

            return Task.FromCanceled(this.frameworkDestroyed.Token);
        }

        if (cancellationToken == default)
            cancellationToken = this.FrameworkThreadTaskFactory.CancellationToken;
        return this.FrameworkThreadTaskFactory.ContinueWhenAll(
            [
                Task.Delay(delay, cancellationToken),
                this.DelayTicks(delayTicks, cancellationToken),
            ],
            _ => func(),
            cancellationToken,
            TaskContinuationOptions.HideScheduler,
            this.frameworkThreadTaskScheduler).Unwrap();
    }

    /// <inheritdoc/>
    public IDebouncer CreateDebouncer(TimeSpan delay, Action action)
    {
        return new Debouncer(this, delay, action);
    }

    /// <summary>
    /// Dispose of managed and unmanaged resources.
    /// </summary>
    void IInternalDisposableService.DisposeService()
    {
        foreach (var k in this.tickDelayedTaskCompletionSources.Keys)
            k.SetCanceled(this.frameworkDestroy.Token);
        this.tickDelayedTaskCompletionSources.Clear();

        this.frameworkDestroyed.Cancel();
        this.updateHook.Dispose();

        this.updateStopwatch.Reset();
        StatsStopwatch.Reset();
    }

    /// <summary>
    /// Adds a update time to the stats history.
    /// </summary>
    /// <param name="key">Delegate Name.</param>
    /// <param name="ms">Runtime.</param>
    internal static void AddToStats(string key, double ms)
    {
        if (!StatsHistory.ContainsKey(key))
            StatsHistory.Add(key, []);

        StatsHistory[key].Add(ms);

        if (StatsHistory[key].Count > 1000)
        {
            StatsHistory[key].RemoveRange(0, StatsHistory[key].Count - 1000);
        }
    }

    /// <summary>
    /// Cancels CancellationTokenSources, sets GameLifecycle to shutting down and unloads Dalamud services.
    /// </summary>
    internal void UnloadDalamud()
    {
        if (this.frameworkDestroy.IsCancellationRequested)
            return;

        this.frameworkDestroy.Cancel();
        this.DispatchUpdateEvents = false;

        // All the same, for now...
        this.lifecycle.SetShuttingDown();
        this.lifecycle.SetUnloading();

        Service<Dalamud>.Get().Unload();
    }

    /// <summary>
    /// Profiles each sub-delegate in the eventDelegate and logs to StatsHistory.
    /// </summary>
    /// <param name="eventDelegate">The Delegate to Profile.</param>
    /// <param name="frameworkInstance">The Framework Instance to pass to delegate.</param>
    /// <param name="errorHandler">A function that is called with the exception, if one arrises.</param>
    internal void ProfileAndInvoke(IFramework.OnUpdateDelegate? eventDelegate, IFramework frameworkInstance, Action<Exception, string>? errorHandler = null)
    {
        // Individually invoke OnUpdate handlers and time them.
        foreach (var d in Delegate.EnumerateInvocationList(eventDelegate))
        {
            var isScopedService = d.Method.DeclaringType == typeof(FrameworkPluginScoped); // ignore FrameworkPluginScoped.OnUpdateForward itself
            var startTime = Stopwatch.GetTimestamp();

            try
            {
                d(frameworkInstance);
            }
            catch (Exception ex)
            {
                if (errorHandler != null)
                {
                    errorHandler?.InvokeSafely(ex, GetFullHandlerName(d));
                }
                else if (!isScopedService)
                {
                    Log.Error(ex, "Exception while dispatching Framework::Update event.");
                }
            }

            var elapsedMilliseconds = Stopwatch.GetElapsedTime(startTime).TotalMilliseconds;

            if (!isScopedService && StatsEnabled)
            {
                var key = GetFullHandlerName(d);
                this.NonUpdatedSubDelegates.Remove(key);
                AddToStats(key, elapsedMilliseconds);
            }

            if (!isScopedService && elapsedMilliseconds > this.configuration.FrameworkUpdateHitch)
            {
                var now = DateTime.UtcNow;
                var cooldownTimeSpan = TimeSpan.FromSeconds(30);
                var key = GetFullHandlerName(d);

                var hasCooldown = this.HitchLogHistory.TryGetValue(key, out var lastLogTimestamp);
                if (!hasCooldown || (hasCooldown && now - lastLogTimestamp > cooldownTimeSpan))
                {
                    this.HitchLogHistory[key] = now;
                    Serilog.Log.Warning("[HITCH] Long {Name} detected, {Total}ms > {Max}ms", key, elapsedMilliseconds, this.configuration.FrameworkUpdateHitch);
                }

                // Clean up old entries in HitchLogHistory
                var threshold = now - cooldownTimeSpan;
                foreach (var rmKey in this.HitchLogHistory.Where(kvp => kvp.Value < threshold).Select(kvp => kvp.Key).ToArray())
                {
                    this.HitchLogHistory.Remove(rmKey);
                }
            }
        }

        static string GetFullHandlerName(IFramework.OnUpdateDelegate d) => $"{d.Method.DeclaringType?.FullName ?? d.Target}::{d.Method.Name}";
    }

    private unsafe bool HandleFrameworkUpdate(CSFramework* thisPtr)
    {
        this.RunFrameworkTick();

        return this.updateHook.OriginalDisposeSafe(thisPtr);
    }

    private unsafe void RunFrameworkTick()
    {
        this.frameworkThreadTaskScheduler.BoundThread ??= Thread.CurrentThread;

        ThreadSafety.MarkMainThread();

        this.ProfileAndInvoke(this.BeforeUpdate, this);

        try
        {
            this.configuration.Update();
        }
        catch (Exception ex)
        {
            Log.Error(ex, "Exception in DalamudConfiguration.Update.");
        }

        this.updateStopwatch.Stop();
        this.UpdateDelta = TimeSpan.FromMilliseconds(this.updateStopwatch.ElapsedMilliseconds);
        this.updateStopwatch.Restart();

        this.LastUpdate = DateTime.Now;
        this.LastUpdateUTC = DateTime.UtcNow;
        this.tickCounter++;
        foreach (var (k, (expiry, ct)) in this.tickDelayedTaskCompletionSources)
        {
            if (ct.IsCancellationRequested)
                k.SetCanceled(ct);
            else if (expiry <= this.tickCounter)
                k.SetResult();
            else
                continue;

            this.tickDelayedTaskCompletionSources.Remove(k, out _);
        }

        if (StatsEnabled)
        {
            StatsStopwatch.Restart();
            this.frameworkThreadTaskScheduler.Run();
            StatsStopwatch.Stop();

            AddToStats(nameof(this.frameworkThreadTaskScheduler), StatsStopwatch.Elapsed.TotalMilliseconds);
        }
        else
        {
            this.frameworkThreadTaskScheduler.Run();
        }

        // Only call Update as long as we're in the actual Framework loop
        if (this.DispatchUpdateEvents)
        {
            // Stat Tracking for Framework Updates
            if (StatsEnabled)
            {
                this.NonUpdatedSubDelegates = StatsHistory.Keys.ToList();
            }

            this.ProfileAndInvoke(this.Update, this);

            // Cleanup handlers that are no longer being called
            if (StatsEnabled)
            {
                foreach (var key in this.NonUpdatedSubDelegates)
                {
                    if (key == nameof(this.FrameworkThreadTaskFactory))
                        continue;

                    if (StatsHistory[key].Count > 0)
                    {
                        StatsHistory[key].RemoveAt(0);
                    }
                    else
                    {
                        StatsHistory.Remove(key);
                    }
                }
            }
        }
    }
}

/// <summary>
/// Plugin-scoped version of a Framework service.
/// </summary>
[PluginInterface]
[ServiceManager.ScopedService]
#pragma warning disable SA1015
[ResolveVia<IFramework>]
#pragma warning restore SA1015
internal class FrameworkPluginScoped : IInternalDisposableService, IFramework
{
    private readonly LocalPlugin plugin;
    private readonly PluginErrorHandler pluginErrorHandler;

    [ServiceManager.ServiceDependency]
    private readonly Framework frameworkService = Service<Framework>.Get();

    /// <summary>
    /// Initializes a new instance of the <see cref="FrameworkPluginScoped"/> class.
    /// </summary>
    /// <param name="plugin">The plugin.</param>
    /// <param name="pluginErrorHandler">Error handler instance.</param>
    internal FrameworkPluginScoped(LocalPlugin plugin, PluginErrorHandler pluginErrorHandler)
    {
        this.plugin = plugin;
        this.pluginErrorHandler = pluginErrorHandler;

        this.frameworkService.Update += this.OnUpdateForward;
    }

    /// <inheritdoc/>
    public event IFramework.OnUpdateDelegate? Update;

    /// <inheritdoc/>
    public DateTime LastUpdate => this.frameworkService.LastUpdate;

    /// <inheritdoc/>
    public DateTime LastUpdateUTC => this.frameworkService.LastUpdateUTC;

    /// <inheritdoc/>
    public TimeSpan UpdateDelta => this.frameworkService.UpdateDelta;

    /// <inheritdoc/>
    public bool IsInFrameworkUpdateThread => this.frameworkService.IsInFrameworkUpdateThread;

    /// <inheritdoc/>
    public bool IsFrameworkUnloading => this.frameworkService.IsFrameworkUnloading;

    /// <inheritdoc/>
    void IInternalDisposableService.DisposeService()
    {
        this.frameworkService.Update -= this.OnUpdateForward;

        this.Update = null;
    }

    /// <inheritdoc/>
    public TaskFactory GetTaskFactory() => this.frameworkService.GetTaskFactory();

    /// <inheritdoc/>
    public Task DelayTicks(long numTicks, CancellationToken cancellationToken = default) =>
        this.frameworkService.DelayTicks(numTicks, cancellationToken);

    /// <inheritdoc/>
    public Task Run(Action action, CancellationToken cancellationToken = default) =>
        this.frameworkService.Run(action, cancellationToken);

    /// <inheritdoc/>
    public Task<T> Run<T>(Func<T> action, CancellationToken cancellationToken = default) =>
        this.frameworkService.Run(action, cancellationToken);

    /// <inheritdoc/>
    public Task Run(Func<Task> action, CancellationToken cancellationToken = default) =>
        this.frameworkService.Run(action, cancellationToken);

    /// <inheritdoc/>
    public Task<T> Run<T>(Func<Task<T>> action, CancellationToken cancellationToken = default) =>
        this.frameworkService.Run(action, cancellationToken);

    /// <inheritdoc/>
    public Task<T> RunOnFrameworkThread<T>(Func<T> func)
        => this.frameworkService.RunOnFrameworkThread(func);

    /// <inheritdoc/>
    public Task RunOnFrameworkThread(Action action)
        => this.frameworkService.RunOnFrameworkThread(action);

    /// <inheritdoc/>
    public Task<T> RunOnFrameworkThread<T>(Func<Task<T>> func)
        => this.frameworkService.RunOnFrameworkThread(func);

    /// <inheritdoc/>
    public Task RunOnFrameworkThread(Func<Task> func)
        => this.frameworkService.RunOnFrameworkThread(func);

    /// <inheritdoc/>
    public Task<T> RunOnTick<T>(Func<T> func, TimeSpan delay = default, int delayTicks = default, CancellationToken cancellationToken = default)
        => this.frameworkService.RunOnTick(func, delay, delayTicks, cancellationToken);

    /// <inheritdoc/>
    public Task RunOnTick(Action action, TimeSpan delay = default, int delayTicks = default, CancellationToken cancellationToken = default)
        => this.frameworkService.RunOnTick(action, delay, delayTicks, cancellationToken);

    /// <inheritdoc/>
    public Task<T> RunOnTick<T>(Func<Task<T>> func, TimeSpan delay = default, int delayTicks = default, CancellationToken cancellationToken = default)
        => this.frameworkService.RunOnTick(func, delay, delayTicks, cancellationToken);

    /// <inheritdoc/>
    public Task RunOnTick(Func<Task> func, TimeSpan delay = default, int delayTicks = default, CancellationToken cancellationToken = default)
        => this.frameworkService.RunOnTick(func, delay, delayTicks, cancellationToken);

    /// <inheritdoc/>
    public IDebouncer CreateDebouncer(TimeSpan delay, Action action)
        => this.frameworkService.CreateDebouncer(delay, action);

    private void OnUpdateForward(IFramework framework)
    {
        this.frameworkService.ProfileAndInvoke(this.Update, this, (ex, handlerName) =>
        {
            Serilog.Log.Error(ex, $"[{this.plugin.InternalName}] Exception in event handler {{EventHandlerName}}", handlerName);
            this.pluginErrorHandler.NotifyError();
        });
    }
}
