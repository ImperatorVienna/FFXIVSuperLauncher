using Dalamud.Plugin.Services;

namespace Dalamud.Game.ClientState.Keys;

/// <summary>
/// Client state memory address resolver.
/// </summary>
internal sealed class KeyStateAddressResolver : BaseAddressResolver
{
    // Static offsets

    /// <summary>
    /// Gets the address of the keyboard state.
    /// </summary>
    public nint KeyboardState { get; private set; }

    /// <summary>
    /// Gets the address of the keyboard state index array which translates the VK enumeration to the key state.
    /// </summary>
    public nint KeyboardStateIndexArray { get; private set; }

    /// <summary>
    /// Scan for and setup any configured address pointers.
    /// </summary>
    /// <param name="sig">The signature scanner to facilitate setup.</param>
    protected override void Setup64Bit(ISigScanner sig)
    {
        // These resolve to fixed offsets only, without the base address added in, so GetStaticAddressFromSig() can't be used.
        // lea   rcx, ds:1DB9F74h[rax*4]          KeyboardState
        // movzx edx, byte ptr [rbx+rsi+1D5E0E0h] KeyboardStateIndexArray
        this.KeyboardState = sig.ScanText("48 8D 0C 85 ?? ?? ?? ?? 8B 04 31 85 C2 0F 85") + 0x4;
        this.KeyboardStateIndexArray = sig.ScanText("0F B6 94 33 ?? ?? ?? ?? 84 D2") + 0x4;
    }
}
