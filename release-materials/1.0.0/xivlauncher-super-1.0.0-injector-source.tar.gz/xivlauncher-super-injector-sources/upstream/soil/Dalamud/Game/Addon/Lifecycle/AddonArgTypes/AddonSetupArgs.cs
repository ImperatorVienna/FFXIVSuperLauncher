using System.Collections.Generic;

using Dalamud.Game.NativeWrapper;

using FFXIVClientStructs.FFXIV.Component.GUI;
using FFXIVClientStructs.Interop;

namespace Dalamud.Game.Addon.Lifecycle.AddonArgTypes;

/// <summary>
/// Addon argument data for Setup events.
/// </summary>
public class AddonSetupArgs : AddonArgs
{
    /// <summary>
    /// Initializes a new instance of the <see cref="AddonSetupArgs"/> class.
    /// </summary>
    internal AddonSetupArgs()
    {
    }

    /// <inheritdoc/>
    public override AddonArgsType Type => AddonArgsType.Setup;

    /// <summary>
    /// Gets or sets the number of AtkValues.
    /// </summary>
    public uint AtkValueCount { get; set; }

    /// <summary>
    /// Gets or sets the address of the AtkValue array.
    /// </summary>
    public nint AtkValues { get; set; }

    /// <summary>
    /// Gets an enumerable collection of <see cref="AtkValuePtr"/> of the event's AtkValues.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerable{T}"/> of <see cref="AtkValuePtr"/> corresponding to the event's AtkValues.
    /// </returns>
    public IEnumerable<AtkValuePtr> AtkValueEnumerable
    {
        get
        {
            for (var i = 0; i < this.AtkValueCount; i++)
            {
                AtkValuePtr ptr;
                unsafe
                {
#pragma warning disable CS0618 // Type or member is obsolete
                    ptr = new AtkValuePtr((nint)this.AtkValueSpan.GetPointer(i));
#pragma warning restore CS0618 // Type or member is obsolete
                }

                yield return ptr;
            }
        }
    }

    /// <summary>
    /// Gets the AtkValues in the form of a span.
    /// </summary>
    internal unsafe Span<AtkValue> AtkValueSpan => new(this.AtkValues.ToPointer(), (int)this.AtkValueCount);
}
