# FFXIV Super Launcher 0.3.1

新增离线插件管理和跨区服插件同步，其他界面保持原有布局，继承 0.3.0 的配置目录和启动响应修正。

“区服和本地化”页提供三个独立按钮：

- Dalamud 设置：仅 `dalamud/dalamudConfig.json`。
- 已安装插件：`dalamud/installedPlugins/`。
- 插件设置：`dalamud/pluginConfigs/`。

点击后选择来源区服，确认后完整覆盖另外两个区服对应内容，来源保持不变。目标原内容保留在数据根目录 `sync-backups/` 下，发生普通异常时尝试自动还原。没有来源数据时禁止同步；游戏运行时拒绝操作。

不复制账号、客户端路径、Dalamud 主程序、运行时或资源。台服和全球服可以预存数据，但尚不支持登录启动；复制插件不保证跨区服插件兼容性。

112 项离线测试通过，包含所有来源区服和同步类别、覆盖范围、备份、失败回滚、取消及权限检查。界面使用临时配置检查；未对用户实际插件目录执行同步。真实游戏回归仍需实机测试。

## 插件管理

新增“插件管理”页，使用“区服和本地化”当前选定区服的数据。勾选或取消勾选不会写入文件；点击“应用插件启用状态”统一保存，点击“放弃修改”重新读取已保存状态。操作不需要启动游戏，保存时需退出游戏。

使用 Dalamud 的插件集合启用记录，兼容 `$type` / `$values` 存储格式；不加载插件 DLL。手动启用将该插件加入默认集合，禁用则关闭该插件在所有集合中的启用项。横线代表受集合条件控制，不改动则保留原规则。不会删除插件文件、配置或修改其他插件。设置文件原内容备份到 `plugin-state-backups/`；发现外部修改时拒绝用旧列表覆盖。

实现格式依据国服上游 [ProfileManager](https://github.com/ottercorp/Dalamud/blob/master/Dalamud/Plugin/Internal/Profiles/ProfileManager.cs)、[ProfileModelV1](https://github.com/ottercorp/Dalamud/blob/master/Dalamud/Plugin/Internal/Profiles/ProfileModelV1.cs) 和 [DalamudConfiguration](https://github.com/ottercorp/Dalamud/blob/master/Dalamud/Configuration/Internal/DalamudConfiguration.cs)。测试包含集合规则、批量应用、旧数据、跨区服隔离、陈旧列表拒绝覆盖以及未知格式保护；实际 Soil 游戏内启用状态仍需用户验收。
