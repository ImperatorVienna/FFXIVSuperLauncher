# 0.10.2：繁中区启动后注入

繁中区认证和会话请求已在用户实机通过，但注入器 launch 模式会执行不适用于该客户端的 FfxivArgLauncher.ArgFixer，在 Iced.Intel.Assembler.nop(sizeInBytes) 抛异常并退出 2。

参照 xl_tw 改为启动游戏、等待窗口、再调用原有 Dalamud.Injector inject。包内新增约数 KB 的 Wine-side 原生助手，取得正确的 Windows PID；继续复用原有 Proton 环境、Dalamud 下载及路径/参数构造。仅繁中区启用 Dalamud 使用此方式。中国区、国际区注入方式及插件管理核心不变。失败不会擅自关闭已经运行的游戏。

验证：281 项离线回归测试通过；使用隔离环境的模拟游戏和模拟注入器，在 Wine 及 proton-cachyos 下验证窗口等待、Windows PID、含空格/引号/尾反斜杠的参数传递。真实游戏注入尚需实机验证，未重复尝试真实账户登录。

国际区：用户机器的 Steam 注册脚本仍指向 0.9.3，截图也显示旧版先更新后登录的顺序。本版不宣称修复国际区服务端拒绝。请从新的解压目录直接打开启动器，在“兼容性工具设置”保持注册选项勾选并保存，使 Steam 入口指向新版本后再验证。
