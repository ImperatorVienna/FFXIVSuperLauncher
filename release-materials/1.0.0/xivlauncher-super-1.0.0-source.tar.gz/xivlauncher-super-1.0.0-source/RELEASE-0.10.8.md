# 0.10.8

繁中区 Dalamud 在 Proton 下初始化 ChatGui 时，日志显示 Reloaded.Assembler / FASMX64 访问冲突（0xC0000005），此时无用户插件加载。仅繁中区启用 Dalamud 自带 DALAMUD_FORCE_MINHOOK=true 开关，改用 MinHook，绕开该钩子创建路径。中国区和国际区不主动设置此开关，不改动账号认证、插件状态或用户 Dalamud 配置。

已核验当前繁中 Dalamud 的 EnvironmentConfiguration 和 Hook.FromAddress 实现确实支持此开关。该补丁需用户实机验证，不宣称所有繁中 Dalamud 兼容问题均已解决。
