# 0.12.13 / 0.12.14 — stable-channel update validation

These two 0.12.x builds verify the production stable update channel. They are published as regular Releases, not prereleases. Both use the same implementation and long-term public signing key.

- AppImage-only distribution; removed all AUR update and packaging code.
- Stable Steam and desktop entry in the settings directory, refreshed whenever an AppImage is launched.
- Updates keep the new versioned filename, switch the entry after verification, and retain a `.previous` backup.
- After manually moving or renaming an AppImage, run it once to refresh the entry. Multiple copies follow the last one launched.
- Re-register Steam and re-add the menu entry once when upgrading from old direct-path releases.
- Four-language README and setup/registration prompts updated.

The repository main branch currently contains documentation. Use the attached versioned source archive and corresponding-source attachments for this build, not GitHub's automatic source archives.
