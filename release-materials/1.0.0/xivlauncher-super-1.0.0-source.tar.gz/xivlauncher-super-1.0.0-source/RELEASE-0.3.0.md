# FFXIV Super Launcher 0.3.0

包名与可执行文件仍为 `xivlauncher-super`。

- 主界面标题改为 FFXIV Super Launcher。
- 数据根目录改为 `~/.local/share/xivlauncher-super/`，支持 XDG_DATA_HOME；已移除旧版自动迁移代码及专用测试。旧目录不读取、不搬运、不删除，首次运行需要重新配置。
- Proton 扫描数量只显示在 Steam/Proton 选择框下方；登录、取消按钮、启动状态和诊断日志只显示在登录页。其他页面具有各自的设置/更新状态。
- Steam 添加/移除已由用户实测通过，本轮按完成处理。实际 Steam 启动验收推迟到全球服 Steam 账号认证开发时进行。

## PID 确认修正

在本机 proton-cachyos-11.0-20261005 与 Steam Linux Runtime 4 中复现：同一 Windows 批处理输出模拟 PID，`proton run` 退出码为 0 但 stdout 为空，旧启动方式无法确认；`proton runinprefix` 可正常返回并由 UnixDalamudRunner 读到 PID 321。

本机 Proton 源码中 `run` 经过 `steam.exe` 启动层，`runinprefix` 直接运行 Wine 目标。新版先用 `run` 执行无操作命令，完成 Proton prefix/DXVK 初始化和版本标记，再用 `runinprefix` 直接执行注入器；保留原来的 Steam Runtime 主会话与全部注入参数。环境准备发生在取得短期登录票据之前。

过滤 STEAM_COMPAT_MOUNTS 中容器保留的系统目录，避免重复提交 `/usr` 等挂载；Proton 工具目录仍通过 STEAM_COMPAT_TOOL_PATHS 提供。普通诊断警告不作为启动失败依据，只有结构化 PID 响应才确认游戏启动；未确认或真实错误继续展示，退出码 0 本身不算成功。游戏启动确认不等同于 Dalamud 加载确认。

## 验证边界

85 项离线测试通过，包含保留注入响应的完整准备/启动流程、挂载过滤、新配置不导入旧目录及原有补丁回归测试。使用临时配置检查三个选项卡。真实 proton-cachyos 的模拟响应测试已通过，没有自动登录账号或启动真实游戏；最终游戏与 Dalamud 实机回归需用户完成。
