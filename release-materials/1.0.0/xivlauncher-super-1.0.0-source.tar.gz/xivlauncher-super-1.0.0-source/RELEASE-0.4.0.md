# FFXIV Super Launcher 0.4.0

本轮加入台服支持，保留原有选项卡布局。

- 台服使用提供的 `xl_tw` 登录机制和官方补丁服务器；Linux 用独立 Chromium 系浏览器替换 WebView2，完成官方 reCAPTCHA 后获取登录会话。支持手动六位验证码、保存 Base32 密钥自动生成 TOTP，以及记住密码。
- 台服 Dalamud 使用 yanmucorp 发行及资源源、上游固定 .NET 9.0.11。国服继续使用 Soil，互不混用。
- 国服目录标识为 `ffxiv_cn`，台服 `ffxiv_tc`，全球服 `ffxiv`。配置根仍是 `xivlauncher-super`；Steam/Proton/prefix 继续共用。
- 所有区服默认使用桌面密码管理器，可取消勾选改为区服内明文 `credentials.json`，切换前弹出警告。保存和读取按账号、区服与所选存储隔离，不静默回退到明文。
- 游戏更新按钮移到登录页，启动前自动检查并更新。只有启用 Dalamud 才更新其程序/运行时/资源。
- 未启用 Dalamud：台服直接由 Proton 启动；国服使用固定随包参数修复辅助组件，不包含 Dalamud 主程序、不会下载或更新，仅以 `--without-dalamud` 运行。因新增固定 Windows .NET 启动依赖，包体比 0.3.1 增大。

## 系统依赖

台服网页验证需安装 `chromium` 或 PATH 中可用的 Chrome/Brave/Edge；桌面密码管理器需 `secret-tool` / `libsecret` 和可用的 Secret Service 密钥环。测试所用临时 Chrome 未安装到用户系统，Firefox 不能用于本版的该验证窗口。

## 验证范围

133 项离线测试通过，覆盖台服登录请求顺序、TOTP 标准向量、补丁 SHA1 校验及模拟安装、区服隔离、明文文件权限、异常配置保护和关闭 Dalamud 时不调用更新器。台服官方 reCAPTCHA 令牌回传、完整 Dalamud/资源更新、台服注入器帮助命令及固定国服辅助组件已在临时环境检查。

用户尚未安装台服客户端，因此未进行实际账号登录、真实台服补丁安装或 Dalamud 游戏内注入测试。国服禁用 Dalamud 的实际账号启动也需回归。没有自动使用用户账号登录。

## 源码来源

台服协议、运行时和 ZiPatch 代码依据用户提供的 `xl_tw`（XIVTCLauncher）移植；未复制 WPF、WebView2、自更新器或 Windows 凭据管理器。Windows 游戏、注入器及固定启动辅助依赖仍通过 Proton 运行，不提供 Windows/macOS 启动器发行版。
